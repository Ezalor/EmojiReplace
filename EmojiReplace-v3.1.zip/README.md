# 替换 Emoji 为最新的 Android 原生版
将 emoji 替换为最新的 Android 原生版本。

## 更新日志
v3.1

    - 更新到 Android O DP4
v3-2

    - 更新到 Android O DP3
    - 同步更新（Template v3）

v3

    - 同步更新（Magisk v10）

v2

    - 更新到 7.1.1 API25

v1

    - 第一版
