# 替换 Emoji 为 Nougat 版
将 emoji 替换为最新的 Nougat 版本。